<?php
/**
 * Define language settings
 * The filename is equal to the languabe code and can not be longer than 10 characters
 * it is recomended to use one of the ISO language codes http://www.loc.gov/standards/iso639-2/php/code_list.php
 *
 * By default the system supports the german and english language
 */
$language_code = "en";

/**
 * Start language package
 *
 * The string convenction is an array following a structure what starts first with the page identification
 * and then a local identification for the page. This means that you can use a key on every page without
 * having troubles. It is recomended to use integres and write its useage as a comment behind the text if
 * required.
 */

/**
 * Menu
 */
$plugin = new Plugin();
$plugin->plugin_name = 'sample-plugin'; // Set pluginname

// Sample pages (Use this structure for every container)
$plugin_container = $plugin->get_page('Test')["id"]; // Get container
$string[$plugin_container]["menu"] = 'Test EN'; // Set containername
$string[$plugin->get_subpage('Sub-Test 1', $plugin_container)["id"]]["menu"] = 'Sub-Test 1 EN'; // Submenu items
$string[$plugin->get_subpage('Sub Test 2', $plugin_container)["id"]]["menu"] = 'Sub-Test 2 EN'; // Submenu items

/**
 * Custom text
 */
$string[$plugin->get_subpage('Sub-Test 1', $plugin_container)["id"]][0] = "This is page #%pageid% called <strong>%pagename%</strong>";
$string[$plugin->get_subpage('Sub Test 2', $plugin_container)["id"]][0] = "This is page #%pageid% called <strong>%pagename%</strong>";
